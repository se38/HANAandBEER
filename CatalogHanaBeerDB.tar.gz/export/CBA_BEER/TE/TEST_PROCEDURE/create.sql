CREATE PROCEDURE "CBA_BEER"."TEST_PROCEDURE" (OUT breweries "CBA_BEER"."tt_breweries")
 LANGUAGE GRAPH READS SQL DATA AS
  BEGIN
	Graph g = Graph("CBA_BEER","beer_graph");

	Graph breweryGraph = SUBGRAPH(:g, v IN Vertices(:g) WHERE :v."TYPE" == 'BREWERY');
	breweries = select :v."NAME" FOREACH v in VERTICES(:breweryGraph);
  END